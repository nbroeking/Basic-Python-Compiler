#!/usr/bin/python

x = 1 + 2 # test
y = (1 + 2 \
        +- 3  +--2) \
         + (1 +- 2) +- (1) ######

print x
print y

yolo = (((((y)))+x))


(((x+5)+2)+-1)+-(3+4+--3--4)

print \
    yolo
