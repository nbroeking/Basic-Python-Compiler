#!/usr/bin/python

x = 1 + 2 # test
y = (1 + 2 +-- 3  +-2) + (1 +- 2) +- (1) ######

print x
print y

yolo = (((((y)))+x))


print yolo
